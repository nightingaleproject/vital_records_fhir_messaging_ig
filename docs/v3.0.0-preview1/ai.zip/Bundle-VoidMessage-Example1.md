# VoidMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **VoidMessage-Example1**

## Example Bundle: VoidMessage-Example1

Profile: [Void Message (for mortality, birth, and fetal death)](StructureDefinition-VRM-VoidMessage.md)

Bundle VoidMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/VoidHeader-Example1

Resource MessageHeader:

> 

Profile: [Void Header](StructureDefinition-VRM-VoidHeader.md)

**event**:`http://nchs.cdc.gov/vrdr_submission_void`
> **destination**

> **source**
**focus**:[Parameters: cert_no, block_count, jurisdiction_id, event_year, state_auxiliary_id](Bundle-VoidMessage-Example1.md#http-//www.example.org/fhir/Parameters/VoidParameters-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/VoidParameters-Example1

Resource Parameters:

> 

Profile: [Void Message Parameters](StructureDefinition-VRM-VoidParameters.md)

## Parameters




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "VoidMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-VoidMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/VoidHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "VoidHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-VoidHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_VoidHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader VoidHeader-Example1</b></p><a name=\"VoidHeader-Example1\"> </a><a name=\"hcVoidHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-VoidHeader.html\">Void Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/vrdr_submission_void\">http://nchs.cdc.gov/vrdr_submission_void</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/vrdr_submission\">http://nchs.cdc.gov/vrdr_submission</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><p><b>focus</b>: <a href=\"Bundle-VoidMessage-Example1.html#http-//www.example.org/fhir/Parameters/VoidParameters-Example1\">Parameters: cert_no, block_count, jurisdiction_id, event_year, state_auxiliary_id</a></p></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/vrdr_submission_void",
        "destination" : [
          {
            "endpoint" : "http://nchs.cdc.gov/vrdr_submission"
          }
        ],
        "source" : {
          "endpoint" : "https://sos.ny.gov/vitalrecords"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Parameters/VoidParameters-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/VoidParameters-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "VoidParameters-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-VoidParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 123456
          },
          {
            "name" : "block_count",
            "valueUnsignedInt" : 10
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2018
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          }
        ]
      }
    }
  ]
}

```
