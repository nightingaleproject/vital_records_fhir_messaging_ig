# ParentalDemographicsCodingMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ParentalDemographicsCodingMessage-Example1**

## Example Bundle: ParentalDemographicsCodingMessage-Example1

Profile: [Demographics Coding Message](StructureDefinition-VRM-DemographicsCodingMessage.md)

Bundle ParentalDemographicsCodingMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/ParentalDemographicsCodingHeader-Example1

Resource MessageHeader:

> 

Profile: [Demographics Coding Header](StructureDefinition-VRM-DemographicsCodingHeader.md)

**event**:`http://nchs.cdc.gov/birth_demographics_coding`
> **destination**

> **source**

### Responses

| | | |
| :--- | :--- | :--- |
| - | **Identifier** | **Code** |
| * | BirthReportHeader-Example1 | OK |

**focus**:
* [Bundle: type = collection](Bundle-BirthReportMessage-Example1.md#http-//www.example.org/fhir/Bundle/DummyBundle)
* [Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id](Bundle-BirthReportMessage-Example1.md#http-//www.example.org/fhir/Parameters/ParametersBirth-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/ParametersBirth-Example1

Resource Parameters:

> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters


-------

Entry 3 - fullUrl = http://www.example.org/fhir/Bundle/DummyBundle

Resource Bundle:

> 

Profile: [Placeholder Profile for profile-based slicing](StructureDefinition-VRM-MessageBundle.md)

Bundle DummyBundle of type collection
-------
Entry 1 - fullUrl = http://www.example.org/fhir/Parameters/ParametersBirth-Example1Resource Parameters:
> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ParentalDemographicsCodingMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-DemographicsCodingMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/ParentalDemographicsCodingHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "ParentalDemographicsCodingHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-DemographicsCodingHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_ParentalDemographicsCodingHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader ParentalDemographicsCodingHeader-Example1</b></p><a name=\"ParentalDemographicsCodingHeader-Example1\"> </a><a name=\"hcParentalDemographicsCodingHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-DemographicsCodingHeader.html\">Demographics Coding Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/birth_demographics_coding\">http://nchs.cdc.gov/birth_demographics_coding</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/bfdr_submission\">http://nchs.cdc.gov/bfdr_submission</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>BirthReportHeader-Example1</td><td>OK</td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"Bundle-BirthReportMessage-Example1.html#http-//www.example.org/fhir/Bundle/DummyBundle\">Bundle: type = collection</a></li><li><a href=\"Bundle-BirthReportMessage-Example1.html#http-//www.example.org/fhir/Parameters/ParametersBirth-Example1\">Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id</a></li></ul></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/birth_demographics_coding",
        "destination" : [
          {
            "endpoint" : "http://nchs.cdc.gov/bfdr_submission"
          }
        ],
        "source" : {
          "endpoint" : "https://sos.ny.gov/vitalrecords"
        },
        "response" : {
          "identifier" : "BirthReportHeader-Example1",
          "code" : "ok"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Bundle/DummyBundle"
          },
          {
            "reference" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersBirth-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 111111
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2022
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          },
          {
            "name" : "payload_version_id",
            "valueString" : "BFDRSTU2.0"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Bundle/DummyBundle",
      "resource" : {
        "resourceType" : "Bundle",
        "id" : "DummyBundle",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageBundle"
          ]
        },
        "type" : "collection",
        "entry" : [
          {
            "fullUrl" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1",
            "resource" : {
              "resourceType" : "Parameters",
              "id" : "ParametersBirth-Example1",
              "meta" : {
                "profile" : [
                  "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
                ]
              },
              "parameter" : [
                {
                  "name" : "cert_no",
                  "valueUnsignedInt" : 111111
                },
                {
                  "name" : "jurisdiction_id",
                  "valueString" : "NY"
                },
                {
                  "name" : "event_year",
                  "valueUnsignedInt" : 2022
                },
                {
                  "name" : "state_auxiliary_id",
                  "valueString" : "abcdef10"
                },
                {
                  "name" : "payload_version_id",
                  "valueString" : "BFDRSTU2.0"
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
