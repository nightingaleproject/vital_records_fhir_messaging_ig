# AcknowledgementMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **AcknowledgementMessage-Example1**

## Example Bundle: AcknowledgementMessage-Example1

Profile: [Acknowledgement Message](StructureDefinition-VRM-AcknowledgementMessage.md)

Bundle AcknowledgementMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/AcknowledgementHeader-Example1

Resource MessageHeader:

> 

Profile: [Acknowledgement Header](StructureDefinition-VRM-AcknowledgementHeader.md)

**event**:`http://nchs.cdc.gov/vrdr_acknowledgement`
> **destination**

> **source**

### Responses

| | | |
| :--- | :--- | :--- |
| - | **Identifier** | **Code** |
| * | SubmissionHeader-Example1 | OK |

**focus**:[Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id](Bundle-AcknowledgementMessage-Example1.md#http-//www.example.org/fhir/Parameters/Parameters-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/Parameters-Example1

Resource Parameters:

> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "AcknowledgementMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-AcknowledgementMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/AcknowledgementHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "AcknowledgementHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-AcknowledgementHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_AcknowledgementHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader AcknowledgementHeader-Example1</b></p><a name=\"AcknowledgementHeader-Example1\"> </a><a name=\"hcAcknowledgementHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-AcknowledgementHeader.html\">Acknowledgement Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/vrdr_acknowledgement\">http://nchs.cdc.gov/vrdr_acknowledgement</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/vrdr_acknowledgement\">http://nchs.cdc.gov/vrdr_acknowledgement</a></td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>SubmissionHeader-Example1</td><td>OK</td></tr></table><p><b>focus</b>: <a href=\"Bundle-AcknowledgementMessage-Example1.html#http-//www.example.org/fhir/Parameters/Parameters-Example1\">Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id</a></p></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/vrdr_acknowledgement",
        "destination" : [
          {
            "endpoint" : "https://sos.ny.gov/vitalrecords"
          }
        ],
        "source" : {
          "endpoint" : "http://nchs.cdc.gov/vrdr_acknowledgement"
        },
        "response" : {
          "identifier" : "SubmissionHeader-Example1",
          "code" : "ok"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Parameters/Parameters-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/Parameters-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "Parameters-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 123456
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2018
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          },
          {
            "name" : "payload_version_id",
            "valueString" : "VRDRSTU2.2"
          }
        ]
      }
    }
  ]
}

```
