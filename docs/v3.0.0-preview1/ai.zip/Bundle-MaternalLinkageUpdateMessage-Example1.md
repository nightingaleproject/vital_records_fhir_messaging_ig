# MaternalLinkageUpdateMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MaternalLinkageUpdateMessage-Example1**

## Example Bundle: MaternalLinkageUpdateMessage-Example1

Profile: [Maternal Linkage Update Message](StructureDefinition-VRM-MaternalLinkageUpdateMessage.md)

Bundle MaternalLinkageUpdateMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/MaternalLinkageUpdateHeaderExample1

Resource MessageHeader:

> 

Profile: [Message Update Header](StructureDefinition-VRM-UpdateHeader.md)

**event**:`http://nchs.cdc.gov/maternal_linkage_update`
> **destination**

> **source**
**focus**:
* [Parameters: cert_no, jurisdiction_id, state_auxiliary_id](Bundle-DeathRecordSubmissionMessage-Example1.md#http-//www.example.org/fhir/Parameters/ParametersDeathExample1)
* [Bundle: identifier = placeholder; type = collection](Bundle-MaternalLinkageSubmissionMessage-Example1.md#http-//www.example.org/fhir/Bundle/MaternalLinkageBundle-Birth)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/ParametersDeathExample1

Resource Parameters:

> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters


-------

Entry 3 - fullUrl = http://www.example.org/fhir/Bundle/MaternalLinkageBundle-Birth

Resource Bundle:

> 

Profile: [Maternal Linkage Content Bundle](StructureDefinition-VRM-maternal-linkage-content-bundle.md)

Bundle MaternalLinkageBundle-Birth of type collection
-------
Entry 1 - fullUrl = http://www.example.org/fhir/Parameter/ParametersLinkage-LiveBirthWithCertResource Parameters:
> 

Profile: [Recent Pregnancy Parameters](StructureDefinition-VRM-RecentPregnancyParameters.md)

## Parameters


-------
Entry 2 - fullUrl = http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example1Resource Observation:
> 

Profile: [Birth Record Identifier Child](StructureDefinition-VRM-birth-record-identifier-child.md)

**status**: Final**code**:Birth Record Record Identifier**value**: 717171
> **component****code**:Birthplace**value**: YC

> **component****code**:Birth year**value**: 2024

> **component****code**:index**value**: 1

> **component****code**:availability**value**:Yes




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "MaternalLinkageUpdateMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MaternalLinkageUpdateMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/MaternalLinkageUpdateHeaderExample1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "MaternalLinkageUpdateHeaderExample1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-UpdateHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_MaternalLinkageUpdateHeaderExample1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader MaternalLinkageUpdateHeaderExample1</b></p><a name=\"MaternalLinkageUpdateHeaderExample1\"> </a><a name=\"hcMaternalLinkageUpdateHeaderExample1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-UpdateHeader.html\">Message Update Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/maternal_linkage_update\">http://nchs.cdc.gov/maternal_linkage_update</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/vrdr_submission\">http://nchs.cdc.gov/vrdr_submission</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"Bundle-DeathRecordSubmissionMessage-Example1.html#http-//www.example.org/fhir/Parameters/ParametersDeathExample1\">Parameters: cert_no, jurisdiction_id, state_auxiliary_id</a></li><li><a href=\"Bundle-MaternalLinkageSubmissionMessage-Example1.html#http-//www.example.org/fhir/Bundle/MaternalLinkageBundle-Birth\">Bundle: identifier = placeholder; type = collection</a></li></ul></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/maternal_linkage_update",
        "destination" : [
          {
            "endpoint" : "http://nchs.cdc.gov/vrdr_submission"
          }
        ],
        "source" : {
          "endpoint" : "https://sos.ny.gov/vitalrecords"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Parameters/ParametersDeathExample1"
          },
          {
            "reference" : "http://www.example.org/fhir/Bundle/MaternalLinkageBundle-Birth"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/ParametersDeathExample1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersDeathExample1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 111111
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Bundle/MaternalLinkageBundle-Birth",
      "resource" : {
        "resourceType" : "Bundle",
        "id" : "MaternalLinkageBundle-Birth",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-maternal-linkage-content-bundle"
          ]
        },
        "identifier" : {
          "value" : "placeholder"
        },
        "type" : "collection",
        "entry" : [
          {
            "fullUrl" : "http://www.example.org/fhir/Parameter/ParametersLinkage-LiveBirthWithCert",
            "resource" : {
              "resourceType" : "Parameters",
              "id" : "ParametersLinkage-LiveBirthWithCert",
              "meta" : {
                "profile" : [
                  "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-RecentPregnancyParameters"
                ]
              },
              "parameter" : [
                {
                  "name" : "notes",
                  "valueString" : "Live Birth With Certificate"
                },
                {
                  "name" : "coded_outcome",
                  "valueCodeableConcept" : {
                    "coding" : [
                      {
                        "system" : "http://snomed.info/sct",
                        "code" : "281050002",
                        "display" : "Livebirth"
                      }
                    ]
                  }
                },
                {
                  "name" : "birth_plurality",
                  "valueInteger" : 1
                },
                {
                  "name" : "fetal_death_plurality",
                  "valueInteger" : 0
                },
                {
                  "name" : "preg_status_is_correct",
                  "valueBoolean" : true
                }
              ]
            }
          },
          {
            "fullUrl" : "http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example1",
            "resource" : {
              "resourceType" : "Observation",
              "id" : "BirthRecordIdentifierChild-Example1",
              "meta" : {
                "profile" : [
                  "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-birth-record-identifier-child"
                ]
              },
              "status" : "final",
              "code" : {
                "coding" : [
                  {
                    "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
                    "code" : "birthrecordidentifier"
                  }
                ]
              },
              "valueString" : "717171",
              "component" : [
                {
                  "code" : {
                    "coding" : [
                      {
                        "system" : "http://loinc.org",
                        "code" : "21842-0"
                      }
                    ]
                  },
                  "valueString" : "YC"
                },
                {
                  "code" : {
                    "coding" : [
                      {
                        "system" : "http://loinc.org",
                        "code" : "80904-6"
                      }
                    ]
                  },
                  "valueDateTime" : "2024"
                },
                {
                  "code" : {
                    "coding" : [
                      {
                        "code" : "index"
                      }
                    ]
                  },
                  "valueInteger" : 1
                },
                {
                  "code" : {
                    "coding" : [
                      {
                        "code" : "availability"
                      }
                    ]
                  },
                  "valueCodeableConcept" : {
                    "coding" : [
                      {
                        "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                        "code" : "Y",
                        "display" : "Yes"
                      }
                    ]
                  }
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
