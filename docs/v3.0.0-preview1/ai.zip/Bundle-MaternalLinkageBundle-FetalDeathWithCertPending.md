# MaternalLinkageBundle-FetalDeathWithCertPending - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MaternalLinkageBundle-FetalDeathWithCertPending**

## Example Bundle: MaternalLinkageBundle-FetalDeathWithCertPending

Profile: [Maternal Linkage Content Bundle](StructureDefinition-VRM-maternal-linkage-content-bundle.md)

Bundle MaternalLinkageBundle-FetalDeathWithCertPending of type collection

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Parameter/ParametersLinkage-FetalDeathWithCertPending

Resource Parameters:

> 

Profile: [Recent Pregnancy Parameters](StructureDefinition-VRM-RecentPregnancyParameters.md)

## Parameters


-------

Entry 2 - fullUrl = http://www.example.org/fhir/Observation/FetalDeathRecordIdentifierNoCert-Example4

Resource Observation:

> 

Profile: [Fetal Death Record Identifier](StructureDefinition-VRM-fetal-death-record-identifier.md)

**status**: Final**code**:Fetal Death Record Identifier
> **component****code**:availability**value**:Temporarily unavailable

> **component****code**:index**value**: 1



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "MaternalLinkageBundle-FetalDeathWithCertPending",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-maternal-linkage-content-bundle"
    ]
  },
  "identifier" : {
    "value" : "placeholder"
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Parameter/ParametersLinkage-FetalDeathWithCertPending",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersLinkage-FetalDeathWithCertPending",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-RecentPregnancyParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "notes",
            "valueString" : "Fetal Death"
          },
          {
            "name" : "coded_outcome",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "276507005",
                  "display" : "Fetal Death"
                }
              ]
            }
          },
          {
            "name" : "birth_plurality",
            "valueInteger" : 0
          },
          {
            "name" : "fetal_death_plurality",
            "valueInteger" : 1
          },
          {
            "name" : "preg_status_is_correct",
            "valueBoolean" : true
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/FetalDeathRecordIdentifierNoCert-Example4",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "FetalDeathRecordIdentifierNoCert-Example4",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-fetal-death-record-identifier"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_FetalDeathRecordIdentifierNoCert-Example4\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation FetalDeathRecordIdentifierNoCert-Example4</b></p><a name=\"FetalDeathRecordIdentifierNoCert-Example4\"> </a><a name=\"hcFetalDeathRecordIdentifierNoCert-Example4\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-fetal-death-record-identifier.html\">Fetal Death Record Identifier</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs fetaldeathrecordidentifier}\">Fetal Death Record Identifier</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v3-NullFlavor NAV}\">Temporarily unavailable</span></p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 1</p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "fetaldeathrecordidentifier"
            }
          ]
        },
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v3-NullFlavor",
                  "code" : "NAV",
                  "display" : "Temporarily unavailable"
                }
              ]
            }
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 1
          }
        ]
      }
    }
  ]
}

```
