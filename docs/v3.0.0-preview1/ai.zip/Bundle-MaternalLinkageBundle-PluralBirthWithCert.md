# MaternalLinkageBundle-PluralBirthWithCert - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MaternalLinkageBundle-PluralBirthWithCert**

## Example Bundle: MaternalLinkageBundle-PluralBirthWithCert

Profile: [Maternal Linkage Content Bundle](StructureDefinition-VRM-maternal-linkage-content-bundle.md)

Bundle MaternalLinkageBundle-PluralBirthWithCert of type collection

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Parameter/ParametersLinkage-PluralBirthWithCert

Resource Parameters:

> 

Profile: [Recent Pregnancy Parameters](StructureDefinition-VRM-RecentPregnancyParameters.md)

## Parameters


-------

Entry 2 - fullUrl = http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example1

Resource Observation:

> 

Profile: [Birth Record Identifier Child](StructureDefinition-VRM-birth-record-identifier-child.md)

**status**: Final**code**:Birth Record Record Identifier**value**: 717171
> **component****code**:Birthplace**value**: YC

> **component****code**:Birth year**value**: 2024

> **component****code**:index**value**: 1

> **component****code**:availability**value**:Yes

-------

Entry 3 - fullUrl = http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example2

Resource Observation:

> 

Profile: [Birth Record Identifier Child](StructureDefinition-VRM-birth-record-identifier-child.md)

**status**: Final**code**:Birth Record Record Identifier**value**: 717172
> **component****code**:Birthplace**value**: YC

> **component****code**:Birth year**value**: 2024

> **component****code**:index**value**: 2

> **component****code**:availability**value**:Yes



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "MaternalLinkageBundle-PluralBirthWithCert",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-maternal-linkage-content-bundle"
    ]
  },
  "identifier" : {
    "value" : "placeholder"
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Parameter/ParametersLinkage-PluralBirthWithCert",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersLinkage-PluralBirthWithCert",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-RecentPregnancyParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "notes",
            "valueString" : "Plural Live Birth With Certificate"
          },
          {
            "name" : "coded_outcome",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://snomed.info/sct",
                  "code" : "281050002",
                  "display" : "Livebirth"
                }
              ]
            }
          },
          {
            "name" : "birth_plurality",
            "valueInteger" : 2
          },
          {
            "name" : "fetal_death_plurality",
            "valueInteger" : 0
          },
          {
            "name" : "preg_status_is_correct",
            "valueBoolean" : true
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example1",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BirthRecordIdentifierChild-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-birth-record-identifier-child"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BirthRecordIdentifierChild-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BirthRecordIdentifierChild-Example1</b></p><a name=\"BirthRecordIdentifierChild-Example1\"> </a><a name=\"hcBirthRecordIdentifierChild-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-birth-record-identifier-child.html\">Birth Record Identifier Child</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs birthrecordidentifier}\">Birth Record Record Identifier</span></p><p><b>value</b>: 717171</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21842-0}\">Birthplace</span></p><p><b>value</b>: YC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80904-6}\">Birth year</span></p><p><b>value</b>: 2024</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "birthrecordidentifier"
            }
          ]
        },
        "valueString" : "717171",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "21842-0"
                }
              ]
            },
            "valueString" : "YC"
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "80904-6"
                }
              ]
            },
            "valueDateTime" : "2024"
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 1
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y",
                  "display" : "Yes"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-Example2",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BirthRecordIdentifierChild-Example2",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-birth-record-identifier-child"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BirthRecordIdentifierChild-Example2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BirthRecordIdentifierChild-Example2</b></p><a name=\"BirthRecordIdentifierChild-Example2\"> </a><a name=\"hcBirthRecordIdentifierChild-Example2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-birth-record-identifier-child.html\">Birth Record Identifier Child</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs birthrecordidentifier}\">Birth Record Record Identifier</span></p><p><b>value</b>: 717172</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21842-0}\">Birthplace</span></p><p><b>value</b>: YC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80904-6}\">Birth year</span></p><p><b>value</b>: 2024</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "birthrecordidentifier"
            }
          ]
        },
        "valueString" : "717172",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "21842-0"
                }
              ]
            },
            "valueString" : "YC"
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "80904-6"
                }
              ]
            },
            "valueDateTime" : "2024"
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 2
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y",
                  "display" : "Yes"
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
