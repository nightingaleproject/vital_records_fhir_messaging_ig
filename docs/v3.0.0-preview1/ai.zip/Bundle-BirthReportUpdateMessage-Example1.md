# BirthReportUpdateMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **BirthReportUpdateMessage-Example1**

## Example Bundle: BirthReportUpdateMessage-Example1

Profile: [Birth Report Update Message](StructureDefinition-VRM-BirthReportUpdateMessage.md)

Bundle BirthReportUpdateMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/BirthReportUpdateHeader-Example1

Resource MessageHeader:

> 

Profile: [Message Update Header](StructureDefinition-VRM-UpdateHeader.md)

**event**:`http://nchs.cdc.gov/birth_submission_update`
> **destination**

> **source**
**focus**:
* [Bundle: type = collection](Bundle-BirthReportMessage-Example1.md#http-//www.example.org/fhir/Bundle/DummyBundle)
* [Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id](Bundle-BirthReportMessage-Example1.md#http-//www.example.org/fhir/Parameters/ParametersBirth-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/ParametersBirth-Example1

Resource Parameters:

> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters


-------

Entry 3 - fullUrl = http://www.example.org/fhir/Bundle/DummyBundle

Resource Bundle:

> 

Profile: [Placeholder Profile for profile-based slicing](StructureDefinition-VRM-MessageBundle.md)

Bundle DummyBundle of type collection
-------
Entry 1 - fullUrl = http://www.example.org/fhir/Parameters/ParametersBirth-Example1Resource Parameters:
> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters





## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "BirthReportUpdateMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-BirthReportUpdateMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2022-08-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/BirthReportUpdateHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "BirthReportUpdateHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-UpdateHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_BirthReportUpdateHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader BirthReportUpdateHeader-Example1</b></p><a name=\"BirthReportUpdateHeader-Example1\"> </a><a name=\"hcBirthReportUpdateHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-UpdateHeader.html\">Message Update Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/birth_submission_update\">http://nchs.cdc.gov/birth_submission_update</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://nchs.cdc.gov/vitalrecords\">https://nchs.cdc.gov/vitalrecords</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><p><b>focus</b>: </p><ul><li><a href=\"Bundle-BirthReportMessage-Example1.html#http-//www.example.org/fhir/Bundle/DummyBundle\">Bundle: type = collection</a></li><li><a href=\"Bundle-BirthReportMessage-Example1.html#http-//www.example.org/fhir/Parameters/ParametersBirth-Example1\">Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id</a></li></ul></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/birth_submission_update",
        "destination" : [
          {
            "endpoint" : "https://nchs.cdc.gov/vitalrecords"
          }
        ],
        "source" : {
          "endpoint" : "https://sos.ny.gov/vitalrecords"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Bundle/DummyBundle"
          },
          {
            "reference" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersBirth-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 111111
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2022
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          },
          {
            "name" : "payload_version_id",
            "valueString" : "BFDRSTU2.0"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Bundle/DummyBundle",
      "resource" : {
        "resourceType" : "Bundle",
        "id" : "DummyBundle",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageBundle"
          ]
        },
        "type" : "collection",
        "entry" : [
          {
            "fullUrl" : "http://www.example.org/fhir/Parameters/ParametersBirth-Example1",
            "resource" : {
              "resourceType" : "Parameters",
              "id" : "ParametersBirth-Example1",
              "meta" : {
                "profile" : [
                  "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
                ]
              },
              "parameter" : [
                {
                  "name" : "cert_no",
                  "valueUnsignedInt" : 111111
                },
                {
                  "name" : "jurisdiction_id",
                  "valueString" : "NY"
                },
                {
                  "name" : "event_year",
                  "valueUnsignedInt" : 2022
                },
                {
                  "name" : "state_auxiliary_id",
                  "valueString" : "abcdef10"
                },
                {
                  "name" : "payload_version_id",
                  "valueString" : "BFDRSTU2.0"
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
