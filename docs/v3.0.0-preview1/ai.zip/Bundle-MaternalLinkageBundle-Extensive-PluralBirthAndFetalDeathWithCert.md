# MaternalLinkageBundle-Extensive-PluralBirthAndFetalDeathWithCert - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **MaternalLinkageBundle-Extensive-PluralBirthAndFetalDeathWithCert**

## Example Bundle: MaternalLinkageBundle-Extensive-PluralBirthAndFetalDeathWithCert

Profile: [Maternal Linkage Content Bundle](StructureDefinition-VRM-maternal-linkage-content-bundle.md)

Bundle MaternalLinkageBundle-Extensive-PluralBirthAndFetalDeathWithCert of type collection

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Parameter/ParametersLinkage-Extensive-PluralBirthAndFetalDeath

Resource Parameters:

> 

Profile: [Recent Pregnancy Parameters](StructureDefinition-VRM-RecentPregnancyParameters.md)

## Parameters


-------

Entry 2 - fullUrl = http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-ExtensiveExample1

Resource Observation:

> 

Profile: [Birth Record Identifier Child](StructureDefinition-VRM-birth-record-identifier-child.md)

**status**: Final**code**:Birth Record Record Identifier**value**: 717171
> **component****code**:Birthplace**value**: YC

> **component****code**:Birth year**value**: 2024

> **component****code**:index**value**: 1

> **component****code**:availability**value**:Yes

-------

Entry 3 - fullUrl = http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-ExtensiveExample2

Resource Observation:

> 

Profile: [Birth Record Identifier Child](StructureDefinition-VRM-birth-record-identifier-child.md)

**status**: Final**code**:Birth Record Record Identifier**value**: 717172
> **component****code**:Birthplace**value**: YC

> **component****code**:Birth year**value**: 2024

> **component****code**:index**value**: 2

> **component****code**:availability**value**:Yes

-------

Entry 4 - fullUrl = http://www.example.org/fhir/Observation/FetalDeathRecordIdentifier-ExtensiveExample1

Resource Observation:

> 

Profile: [Fetal Death Record Identifier](StructureDefinition-VRM-fetal-death-record-identifier.md)

**status**: Final**code**:Fetal Death Record Identifier**value**: 100001
> **component****code**:Jurisdiction code**value**: YC

> **component****code**:Date of death [Date]**value**: 2024

> **component****code**:index**value**: 1

> **component****code**:availability**value**:Yes

-------

Entry 5 - fullUrl = http://www.example.org/fhir/Observation/FetalDeathRecordIdentifier-ExtesnvieExample2

Resource Observation:

> 

Profile: [Fetal Death Record Identifier](StructureDefinition-VRM-fetal-death-record-identifier.md)

**status**: Final**code**:Fetal Death Record Identifier
> **component****code**:index**value**: 2

> **component****code**:availability**value**:No



## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "MaternalLinkageBundle-Extensive-PluralBirthAndFetalDeathWithCert",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-maternal-linkage-content-bundle"
    ]
  },
  "identifier" : {
    "extension" : [
      {
        "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/CertificateNumber",
        "valueString" : "000182"
      },
      {
        "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/AuxiliaryStateIdentifier1",
        "valueString" : "000000000001"
      },
      {
        "url" : "http://hl7.org/fhir/us/vr-common-library/StructureDefinition/AuxiliaryStateIdentifier2",
        "valueString" : "100000000001"
      }
    ],
    "value" : "2020NY000182"
  },
  "type" : "collection",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Parameter/ParametersLinkage-Extensive-PluralBirthAndFetalDeath",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "ParametersLinkage-Extensive-PluralBirthAndFetalDeath",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-RecentPregnancyParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "notes",
            "valueString" : "This is a long example of notes to use all characters. Long example of notes to use characters. Test"
          },
          {
            "name" : "coded_outcome",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-coded-pregnancy-status-cs",
                  "code" : "live-birth-and-fetal-death",
                  "display" : "Multiple Outcomes (Live Birth(s) and Fetal Death(s))"
                }
              ]
            }
          },
          {
            "name" : "birth_plurality",
            "valueInteger" : 2
          },
          {
            "name" : "fetal_death_plurality",
            "valueInteger" : 2
          },
          {
            "name" : "preg_status_is_correct",
            "valueBoolean" : false
          },
          {
            "name" : "corrected_pregnancy_status",
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://hl7.org/fhir/us/vrdr/CodeSystem/CodeSystem-death-pregnancy-status",
                  "code" : "4",
                  "display" : "Not pregnant, but pregnant 43 days to 1 year before death"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-ExtensiveExample1",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BirthRecordIdentifierChild-ExtensiveExample1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-birth-record-identifier-child"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BirthRecordIdentifierChild-ExtensiveExample1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BirthRecordIdentifierChild-ExtensiveExample1</b></p><a name=\"BirthRecordIdentifierChild-ExtensiveExample1\"> </a><a name=\"hcBirthRecordIdentifierChild-ExtensiveExample1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-birth-record-identifier-child.html\">Birth Record Identifier Child</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs birthrecordidentifier}\">Birth Record Record Identifier</span></p><p><b>value</b>: 717171</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21842-0}\">Birthplace</span></p><p><b>value</b>: YC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80904-6}\">Birth year</span></p><p><b>value</b>: 2024</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "birthrecordidentifier"
            }
          ]
        },
        "valueString" : "717171",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "21842-0"
                }
              ]
            },
            "valueString" : "YC"
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "80904-6"
                }
              ]
            },
            "valueDateTime" : "2024"
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 1
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y",
                  "display" : "Yes"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/BirthRecordIdentifierChild-ExtensiveExample2",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "BirthRecordIdentifierChild-ExtensiveExample2",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-birth-record-identifier-child"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_BirthRecordIdentifierChild-ExtensiveExample2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation BirthRecordIdentifierChild-ExtensiveExample2</b></p><a name=\"BirthRecordIdentifierChild-ExtensiveExample2\"> </a><a name=\"hcBirthRecordIdentifierChild-ExtensiveExample2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-birth-record-identifier-child.html\">Birth Record Identifier Child</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs birthrecordidentifier}\">Birth Record Record Identifier</span></p><p><b>value</b>: 717172</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 21842-0}\">Birthplace</span></p><p><b>value</b>: YC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 80904-6}\">Birth year</span></p><p><b>value</b>: 2024</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "birthrecordidentifier"
            }
          ]
        },
        "valueString" : "717172",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "21842-0"
                }
              ]
            },
            "valueString" : "YC"
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "80904-6"
                }
              ]
            },
            "valueDateTime" : "2024"
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 2
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y",
                  "display" : "Yes"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/FetalDeathRecordIdentifier-ExtensiveExample1",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "FetalDeathRecordIdentifier-ExtensiveExample1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-fetal-death-record-identifier"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_FetalDeathRecordIdentifier-ExtensiveExample1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation FetalDeathRecordIdentifier-ExtensiveExample1</b></p><a name=\"FetalDeathRecordIdentifier-ExtensiveExample1\"> </a><a name=\"hcFetalDeathRecordIdentifier-ExtensiveExample1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-fetal-death-record-identifier.html\">Fetal Death Record Identifier</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs fetaldeathrecordidentifier}\">Fetal Death Record Identifier</span></p><p><b>value</b>: 100001</p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 77969-4}\">Jurisdiction code</span></p><p><b>value</b>: YC</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:{http://loinc.org 81954-0}\">Date of death [Date]</span></p><p><b>value</b>: 2024</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 1</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 Y}\">Yes</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "fetaldeathrecordidentifier"
            }
          ]
        },
        "valueString" : "100001",
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "77969-4"
                }
              ]
            },
            "valueString" : "YC"
          },
          {
            "code" : {
              "coding" : [
                {
                  "system" : "http://loinc.org",
                  "code" : "81954-0"
                }
              ]
            },
            "valueDateTime" : "2024"
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 1
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "Y",
                  "display" : "Yes"
                }
              ]
            }
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Observation/FetalDeathRecordIdentifier-ExtesnvieExample2",
      "resource" : {
        "resourceType" : "Observation",
        "id" : "FetalDeathRecordIdentifier-ExtesnvieExample2",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-fetal-death-record-identifier"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"Observation_FetalDeathRecordIdentifier-ExtesnvieExample2\"> </a><p class=\"res-header-id\"><b>Generated Narrative: Observation FetalDeathRecordIdentifier-ExtesnvieExample2</b></p><a name=\"FetalDeathRecordIdentifier-ExtesnvieExample2\"> </a><a name=\"hcFetalDeathRecordIdentifier-ExtesnvieExample2\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-fetal-death-record-identifier.html\">Fetal Death Record Identifier</a></p></div><p><b>status</b>: Final</p><p><b>code</b>: <span title=\"Codes:{http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs fetaldeathrecordidentifier}\">Fetal Death Record Identifier</span></p><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">index</span></p><p><b>value</b>: 2</p></blockquote><blockquote><p><b>component</b></p><p><b>code</b>: <span title=\"Codes:\">availability</span></p><p><b>value</b>: <span title=\"Codes:{http://terminology.hl7.org/CodeSystem/v2-0136 N}\">No</span></p></blockquote></div>"
        },
        "status" : "final",
        "code" : {
          "coding" : [
            {
              "system" : "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/CodeSystem/VRM-observation-cs",
              "code" : "fetaldeathrecordidentifier"
            }
          ]
        },
        "component" : [
          {
            "code" : {
              "coding" : [
                {
                  "code" : "index"
                }
              ]
            },
            "valueInteger" : 2
          },
          {
            "code" : {
              "coding" : [
                {
                  "code" : "availability"
                }
              ]
            },
            "valueCodeableConcept" : {
              "coding" : [
                {
                  "system" : "http://terminology.hl7.org/CodeSystem/v2-0136",
                  "code" : "N",
                  "display" : "No"
                }
              ]
            }
          }
        ]
      }
    }
  ]
}

```
