# StatusMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **StatusMessage-Example1**

## Example Bundle: StatusMessage-Example1

Profile: [Status Message](StructureDefinition-VRM-StatusMessage.md)

Bundle StatusMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/StatusHeader-Example1

Resource MessageHeader:

> 

Profile: [Status Header](StructureDefinition-VRM-StatusHeader.md)

**event**:`http://nchs.cdc.gov/vrdr_status`
> **destination**

> **source**

### Responses

| | | |
| :--- | :--- | :--- |
| - | **Identifier** | **Code** |
| * | SubmissionHeader-Example1 | OK |

**focus**:[Parameters: cert_no, status, jurisdiction_id, event_year, state_auxiliary_id](Bundle-StatusMessage-Example1.md#http-//www.example.org/fhir/Parameters/StatusParameters-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/StatusParameters-Example1

Resource Parameters:

> 

Profile: [Status Message Parameters](StructureDefinition-VRM-StatusParameters.md)

## Parameters




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "StatusMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-StatusMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/StatusHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "StatusHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-StatusHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_StatusHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader StatusHeader-Example1</b></p><a name=\"StatusHeader-Example1\"> </a><a name=\"hcStatusHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-StatusHeader.html\">Status Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/vrdr_status\">http://nchs.cdc.gov/vrdr_status</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/vrdr_status\">http://nchs.cdc.gov/vrdr_status</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td></tr><tr><td style=\"display: none\">*</td><td>SubmissionHeader-Example1</td><td>OK</td></tr></table><p><b>focus</b>: <a href=\"Bundle-StatusMessage-Example1.html#http-//www.example.org/fhir/Parameters/StatusParameters-Example1\">Parameters: cert_no, status, jurisdiction_id, event_year, state_auxiliary_id</a></p></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/vrdr_status",
        "destination" : [
          {
            "endpoint" : "http://nchs.cdc.gov/vrdr_status"
          }
        ],
        "source" : {
          "endpoint" : "https://sos.ny.gov/vitalrecords"
        },
        "response" : {
          "identifier" : "SubmissionHeader-Example1",
          "code" : "ok"
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Parameters/StatusParameters-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/StatusParameters-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "StatusParameters-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-StatusParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 123456
          },
          {
            "name" : "status",
            "valueString" : "manualCauseOfDeathCoding"
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2018
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          }
        ]
      }
    }
  ]
}

```
