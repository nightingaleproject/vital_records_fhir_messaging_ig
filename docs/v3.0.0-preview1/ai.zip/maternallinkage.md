# Maternal Linkage Records for Mortality - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* **Maternal Linkage Records for Mortality**

## Maternal Linkage Records for Mortality

### Maternal Linkage Record Messages

Maternal linkage records support a new requirement for VROs to verify the pregnancy status of decedents who were pregnant at the time of death or in the prior year, and to provide information on the outcome of the pregnancy and associated birth and fetal death record certificate IDs when appropriate. Verification is important because pregnancy status reported in death records may not be reliable, and only after the VRO has attempted to link the decedent to birth and fetal death records is the full picture known. Ideally, if the pregnancy status in the death record is incorrect, the Certifier would correct the death record and the VRO would provide NVSS with an updated death record. This is not always possible. These records provide the VRO with the opportunity to verify the pregnancy status in the death record, and if incorrect, to provide a correct status.

Certificates may not be available for births and deaths that happen in other jurisdictions, or in foreign countries. The VRO can provide the outcome of the pregnancy without providing certificate linkages.

This [content of these messages](StructureDefinition-VRM-maternal-linkage-content-bundle.md) is defined within this IG, and is the only message content not defined in one of the HL7 Vital Records content IGs (VRDR and BFDR). An attempt was made to include this content within VRDR STU3, but the resources defined there proved inadequate. For now, this content has been defined in this IG. Once it is stable, it may make sense to incorporate it into the next balloted version of VRDR.

