# ExtractionErrorMessage-Example1 - Vital Records FHIR Messaging (VRFM) IG v3.0.0-Preview1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ExtractionErrorMessage-Example1**

## Example Bundle: ExtractionErrorMessage-Example1

Profile: [Extraction Error Message](StructureDefinition-VRM-ExtractionErrorMessage.md)

Bundle ExtractionErrorMessage-Example1 of type message

-------

Entry 1 - fullUrl = http://www.example.org/fhir/Header/ExtractionErrorHeader-Example1

Resource MessageHeader:

> 

Profile: [Extraction Error Header](StructureDefinition-VRM-ExtractionErrorHeader.md)

**event**:`http://nchs.cdc.gov/vrdr_extraction_error`
> **destination**

> **source**

### Responses

| | | | |
| :--- | :--- | :--- | :--- |
| - | **Identifier** | **Code** | **Details** |
| * | 54a07cef-4bff-4bb0-8957-9c8fbf7390ed | Fatal Error | [OperationOutcome](Bundle-ExtractionErrorMessage-Example1.md#http-//www.example.org/fhir/OperationOutcome/Outcome-Example1) |

**focus**:[Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id](Bundle-AcknowledgementMessage-Example1.md#http-//www.example.org/fhir/Parameters/Parameters-Example1)

-------

Entry 2 - fullUrl = http://www.example.org/fhir/Parameters/Parameters-Example1

Resource Parameters:

> 

Profile: [Message Parameters](StructureDefinition-VRM-MessageParameters.md)

## Parameters


-------

Entry 3 - fullUrl = http://www.example.org/fhir/OperationOutcome/Outcome-Example1

Resource OperationOutcome:

> 

Profile: [Outcome Profile](StructureDefinition-VRM-Outcome.md)




## Resource Content

```json
{
  "resourceType" : "Bundle",
  "id" : "ExtractionErrorMessage-Example1",
  "meta" : {
    "profile" : [
      "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-ExtractionErrorMessage"
    ]
  },
  "type" : "message",
  "timestamp" : "2021-05-20T00:00:00Z",
  "entry" : [
    {
      "fullUrl" : "http://www.example.org/fhir/Header/ExtractionErrorHeader-Example1",
      "resource" : {
        "resourceType" : "MessageHeader",
        "id" : "ExtractionErrorHeader-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-ExtractionErrorHeader"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"MessageHeader_ExtractionErrorHeader-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: MessageHeader ExtractionErrorHeader-Example1</b></p><a name=\"ExtractionErrorHeader-Example1\"> </a><a name=\"hcExtractionErrorHeader-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-ExtractionErrorHeader.html\">Extraction Error Header</a></p></div><p><b>event</b>: <a href=\"http://nchs.cdc.gov/vrdr_extraction_error\">http://nchs.cdc.gov/vrdr_extraction_error</a></p><h3>Destinations</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"https://sos.ny.gov/vitalrecords\">https://sos.ny.gov/vitalrecords</a></td></tr></table><h3>Sources</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Endpoint</b></td></tr><tr><td style=\"display: none\">*</td><td><a href=\"http://nchs.cdc.gov/vrdr_submission\">http://nchs.cdc.gov/vrdr_submission</a></td></tr></table><h3>Responses</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Identifier</b></td><td><b>Code</b></td><td><b>Details</b></td></tr><tr><td style=\"display: none\">*</td><td>54a07cef-4bff-4bb0-8957-9c8fbf7390ed</td><td>Fatal Error</td><td><a href=\"Bundle-ExtractionErrorMessage-Example1.html#http-//www.example.org/fhir/OperationOutcome/Outcome-Example1\">OperationOutcome</a></td></tr></table><p><b>focus</b>: <a href=\"Bundle-AcknowledgementMessage-Example1.html#http-//www.example.org/fhir/Parameters/Parameters-Example1\">Parameters: cert_no, jurisdiction_id, event_year, state_auxiliary_id, payload_version_id</a></p></div>"
        },
        "eventUri" : "http://nchs.cdc.gov/vrdr_extraction_error",
        "destination" : [
          {
            "endpoint" : "https://sos.ny.gov/vitalrecords"
          }
        ],
        "source" : {
          "endpoint" : "http://nchs.cdc.gov/vrdr_submission"
        },
        "response" : {
          "identifier" : "54a07cef-4bff-4bb0-8957-9c8fbf7390ed",
          "code" : "fatal-error",
          "details" : {
            "reference" : "http://www.example.org/fhir/OperationOutcome/Outcome-Example1"
          }
        },
        "focus" : [
          {
            "reference" : "http://www.example.org/fhir/Parameters/Parameters-Example1"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/Parameters/Parameters-Example1",
      "resource" : {
        "resourceType" : "Parameters",
        "id" : "Parameters-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-MessageParameters"
          ]
        },
        "parameter" : [
          {
            "name" : "cert_no",
            "valueUnsignedInt" : 123456
          },
          {
            "name" : "jurisdiction_id",
            "valueString" : "NY"
          },
          {
            "name" : "event_year",
            "valueUnsignedInt" : 2018
          },
          {
            "name" : "state_auxiliary_id",
            "valueString" : "abcdef10"
          },
          {
            "name" : "payload_version_id",
            "valueString" : "VRDRSTU2.2"
          }
        ]
      }
    },
    {
      "fullUrl" : "http://www.example.org/fhir/OperationOutcome/Outcome-Example1",
      "resource" : {
        "resourceType" : "OperationOutcome",
        "id" : "Outcome-Example1",
        "meta" : {
          "profile" : [
            "http://cdc.gov/nchs/nvss/fhir/vital-records-messaging/StructureDefinition/VRM-Outcome"
          ]
        },
        "text" : {
          "status" : "generated",
          "div" : "<div xmlns=\"http://www.w3.org/1999/xhtml\"><a name=\"OperationOutcome_Outcome-Example1\"> </a><p class=\"res-header-id\"><b>Generated Narrative: OperationOutcome Outcome-Example1</b></p><a name=\"Outcome-Example1\"> </a><a name=\"hcOutcome-Example1\"> </a><div style=\"display: inline-block; background-color: #d9e0e7; padding: 6px; margin: 4px; border: 1px solid #8da1b4; border-radius: 5px; line-height: 60%\"><p style=\"margin-bottom: 0px\"/><p style=\"margin-bottom: 0px\">Profile: <a href=\"StructureDefinition-VRM-Outcome.html\">Outcome Profile</a></p></div><h3>Issues</h3><table class=\"grid\"><tr><td style=\"display: none\">-</td><td><b>Severity</b></td><td><b>Code</b></td><td><b>Diagnostics</b></td></tr><tr><td style=\"display: none\">*</td><td>Error</td><td>Structural Issue</td><td>Expected 1 or more Cause of Death Condition resources, received 0.</td></tr></table></div>"
        },
        "issue" : [
          {
            "severity" : "error",
            "code" : "structure",
            "diagnostics" : "Expected 1 or more Cause of Death Condition resources, received 0."
          }
        ]
      }
    }
  ]
}

```
